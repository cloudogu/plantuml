# Examples

- [Additional fonts inside the PlantUML docker container](./additional-fonts)
- [Nginx simple reverse proxy example](./nginx-simple)
- [Nginx reverse proxy example with defined location directive (different context path)](./nginx-contextpath)
- [Kubernetes simple deployment](./kubernetes-simple)
