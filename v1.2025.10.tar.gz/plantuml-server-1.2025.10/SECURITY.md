# Security Policy



## Reporting a Vulnerability

If you find any security concern, please send a mail to plantuml@gmail.com
with title **Security concern**.

We will then study the concern and will answer back by email.

Thanks!
